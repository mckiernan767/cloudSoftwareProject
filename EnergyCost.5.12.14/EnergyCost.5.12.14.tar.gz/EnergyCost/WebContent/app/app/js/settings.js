var config = {

	serverBaseUrl : 'http://' + location.host + '/papillonserver/rest/',
	extrapolateYears: 3
}; 