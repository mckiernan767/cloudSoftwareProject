package com.cloud;

public class Test {
	public static String testVar = "This is a test";
	public static void test() {
		System.out.println("hello");
	}

}

/*<%@ page import =  "com.cloud.SimpleMain" %>
<%SimpleMain.simple(); %>
<%! String jspVar = SimpleMain.output;%>*/